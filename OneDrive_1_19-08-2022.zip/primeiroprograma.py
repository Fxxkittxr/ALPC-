print("Olha pitos e pitas")
