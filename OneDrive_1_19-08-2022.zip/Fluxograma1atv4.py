'''
Construa um algoritmo que retorne o valor total da revelação de um filme de 
24 poses, solicite o número de fotos reveladas. E considere que o valor 
unitário da revelação por foto é de R$ 0,90.
'''
print ("Informe o número de fotos relevadas:")
fr = int(input())
tt = fr * 0.90
print ("O valor a ser pago pelas fotos é de: R$", tt)