'''
Faça um algoritmo para calcular a quantidade de carne necessária para 
um churrasco de acordo com o número de pessoas convidadas. Considere que 
todas são adultas e que um adulto consome 250 gramas de carne por refeição.
'''
print ("Insira o número de pessoas que vão comparecer:")
np = int(input())
tc = np * 250
print ("Total de carne que se deve comprar é",tc,"g")